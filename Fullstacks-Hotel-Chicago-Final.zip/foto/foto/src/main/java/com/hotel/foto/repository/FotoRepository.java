package com.hotel.foto.repository;

import com.hotel.foto.model.Foto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FotoRepository extends JpaRepository<Foto, Long> {
    List<Foto> findByHabitacionIdHab(Long habitacionIdHab);
}