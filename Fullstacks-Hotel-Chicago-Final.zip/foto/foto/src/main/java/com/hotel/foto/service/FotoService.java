package com.hotel.foto.service;

import com.hotel.foto.model.Foto;
import com.hotel.foto.repository.FotoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class FotoService {

    @Autowired
    private FotoRepository repository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Foto> listarPorHabitacion(Long habitacionId) {
        return repository.findByHabitacionIdHab(habitacionId);
    }

    public Foto guardar(Foto foto) {
        try {
            webClientBuilder.build().get()
                    .uri("http://localhost:8082/api/habitaciones/" + foto.getHabitacionIdHab())
                    .retrieve()
                    .toBodilessEntity()
                    .block();
        } catch (Exception e) {
            throw new RuntimeException("Error: La Habitación con ID " + foto.getHabitacionIdHab() + " no existe o el servicio de Habitaciones está caído.");
        }
        return repository.save(foto);
    }
}