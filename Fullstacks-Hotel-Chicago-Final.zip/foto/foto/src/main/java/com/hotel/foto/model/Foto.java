package com.hotel.foto.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "foto")
@Data
public class Foto {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_foto")
    private Long idFoto;

    @Column(name = "url", length = 255)
    private String url;

    @Column(name = "es_portada", length = 2)
    private String esPortada;

    @Column(name = "habitacion_id_hab")
    private Long habitacionIdHab;
}