package com.hotel.foto.controller;

import com.hotel.foto.model.Foto;
import com.hotel.foto.service.FotoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/fotos")
public class FotoController {

    @Autowired
    private FotoService service;

    @GetMapping("/habitacion/{habitacionId}")
    public List<Foto> listarPorHabitacion(@PathVariable Long habitacionId) {
        return service.listarPorHabitacion(habitacionId);
    }

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Foto foto) {
        try {
            Foto nueva = service.guardar(foto);
            return new ResponseEntity<>(nueva, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}