package com.hotel.resena.controller;

import com.hotel.resena.model.Resena;
import com.hotel.resena.repository.ResenaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/resenas")
public class ResenaController {

    @Autowired
    private ResenaRepository repository;

    @GetMapping
    public List<Resena> listar() {
        return repository.findAll();
    }

    @PostMapping
    public ResponseEntity<Resena> crear(@RequestBody Resena resena) {
        Resena nuevo = repository.save(resena);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }
}