package com.hotel.auditoria.controller;

import com.hotel.auditoria.model.Auditoria;
import com.hotel.auditoria.repository.AuditoriaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/auditorias")
public class AuditoriaController {

    @Autowired
    private AuditoriaRepository repository;

    @GetMapping
    public List<Auditoria> listar() {
        return repository.findAll();
    }

    @PostMapping
    public ResponseEntity<Auditoria> crear(@RequestBody Auditoria auditoria) {
        if (auditoria.getFechaHora() == null) {
            auditoria.setFechaHora(LocalDateTime.now());
        }
        Auditoria nuevo = repository.save(auditoria);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }
}