package com.hotel.mantenimiento.controller;

import com.hotel.mantenimiento.model.Mantenimiento;
import com.hotel.mantenimiento.repository.MantenimientoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/mantenimientos")
public class MantenimientoController {

    @Autowired
    private MantenimientoRepository repository;

    @GetMapping
    public List<Mantenimiento> listar() {
        return repository.findAll();
    }

    @PostMapping
    public ResponseEntity<Mantenimiento> crear(@RequestBody Mantenimiento mantenimiento) {
        if (mantenimiento.getFecha() == null) {
            mantenimiento.setFecha(LocalDate.now());
        }
        Mantenimiento nuevo = repository.save(mantenimiento);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }
}