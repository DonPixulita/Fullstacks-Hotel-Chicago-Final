package com.hotel.habitacion.service;

import com.hotel.habitacion.model.Habitacion;
import com.hotel.habitacion.repository.HabitacionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class HabitacionService {

    @Autowired
    private HabitacionRepository repository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Habitacion> listarTodas() {
        return repository.findAll();
    }

public Habitacion guardar(Habitacion hab) {
        try {
            webClientBuilder.build().get()
                    .uri("http://localhost:8083/api/estados/" + hab.getEstadoIdEstado())
                    .retrieve()
                    .toBodilessEntity()
                    .block(); 
        } catch (Exception e) {
            throw new RuntimeException("Error real del sistema: " + e.getMessage());
        }
        
        return repository.save(hab);
    }
}