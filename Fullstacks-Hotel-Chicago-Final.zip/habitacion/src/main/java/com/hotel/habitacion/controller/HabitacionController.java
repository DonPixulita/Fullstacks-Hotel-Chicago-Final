package com.hotel.habitacion.controller;

import com.hotel.habitacion.model.Habitacion;
import com.hotel.habitacion.service.HabitacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/habitaciones")
public class HabitacionController {

    @Autowired
    private HabitacionService service;

    @GetMapping
    public List<Habitacion> listar() {
        return service.listarTodas();
    }

    @PostMapping
    public ResponseEntity<?> crear(@RequestBody Habitacion habitacion) {
        try {
            Habitacion nueva = service.guardar(habitacion);
            return new ResponseEntity<>(nueva, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(e.getMessage(), HttpStatus.BAD_REQUEST);
        }
    }
}