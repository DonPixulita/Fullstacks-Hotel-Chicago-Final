package com.hotel.habitacion.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "habitacion")
@Data
public class Habitacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_habitacion")
    private Long idHabitacion;

    private Integer numero;
    private Integer piso;
    private String observacion;

    @Column(name = "tipo_habitacion_id")
    private Long tipoHabitacionId;

    @Column(name = "estado_id_estado")
    private Long estadoIdEstado; 
}