package com.hotel.huesped.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "huesped")
@Data
public class Huesped {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_huesped")
    private Long idHuesped;

    @Column(name = "documento", length = 20, unique = true)
    private String documento; 

    @Column(name = "nombre", length = 100)
    private String nombre;

    @Column(name = "apellido", length = 100)
    private String apellido;

    @Column(name = "telefono", length = 20)
    private String telefono;

    @Column(name = "correo", length = 100)
    private String correo;
}