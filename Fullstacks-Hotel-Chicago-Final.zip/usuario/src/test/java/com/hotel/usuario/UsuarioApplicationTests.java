package com.hotel.usuario;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = UsuarioApplication.class)
class UsuarioApplicationTests {

	@Test
	void contextLoads() {

	}

}