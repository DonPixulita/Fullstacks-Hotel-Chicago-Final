package com.hotel.usuario.controller;

import com.hotel.usuario.model.Usuario;
import com.hotel.usuario.repository.UsuarioRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

public class UsuarioControllerTest {

    @InjectMocks
    private UsuarioController usuarioController;

    @Mock
    private UsuarioRepository repository;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void debeListarUsuariosExitosamente() {
        Usuario mockUsuario = new Usuario();
        mockUsuario.setIdUsuario(1L);
        mockUsuario.setNombre("Diego Armando");
        mockUsuario.setCorreo("diego@hotelchicago.com");
        
        Mockito.when(repository.findAll()).thenReturn(Arrays.asList(mockUsuario));

        List<Usuario> resultado = usuarioController.listar();

        assertNotNull(resultado);
        assertEquals(1, resultado.size());
        assertEquals("Diego Armando", resultado.get(0).getNombre());
    }

    @Test
    public void debeCrearUsuarioExitosamente() {
        Usuario nuevoUsuario = new Usuario();
        nuevoUsuario.setNombre("Carlos");
        nuevoUsuario.setCorreo("carlos@hotel.com");

        Usuario usuarioGuardado = new Usuario();
        usuarioGuardado.setIdUsuario(2L);
        usuarioGuardado.setNombre("Carlos");
        usuarioGuardado.setCorreo("carlos@hotel.com");

        Mockito.when(repository.save(Mockito.any(Usuario.class))).thenReturn(usuarioGuardado);

        ResponseEntity<Usuario> respuesta = usuarioController.crear(nuevoUsuario);

        assertEquals(HttpStatus.CREATED, respuesta.getStatusCode());
        assertNotNull(respuesta.getBody());
        assertEquals(2L, respuesta.getBody().getIdUsuario());
    }
}