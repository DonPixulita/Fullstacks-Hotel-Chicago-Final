package com.hotel.estado.controller;

import com.hotel.estado.model.Estado;
import com.hotel.estado.repository.EstadoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estados") 
public class EstadoController {

    @Autowired
    private EstadoRepository repository;

    @GetMapping
    public List<Estado> listar() {
        return repository.findAll();
    }

@GetMapping("/{id}")
    public ResponseEntity<Estado> buscarPorId(@PathVariable Long id) {
        return repository.findById(id)
                .map(estado -> new ResponseEntity<>(estado, HttpStatus.OK))
                .orElse(new ResponseEntity<>(HttpStatus.NOT_FOUND)); 
    }

    // 3. Crear Estado
    @PostMapping
    public ResponseEntity<Estado> crear(@RequestBody Estado estado) {
        Estado nuevo = repository.save(estado);
        return new ResponseEntity<>(nuevo, HttpStatus.CREATED);
    }
}