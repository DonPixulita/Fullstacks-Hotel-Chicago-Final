package com.hotel.reserva;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReservaApplicationTests {

	@Test
	void contextLoads() {
	}

}
