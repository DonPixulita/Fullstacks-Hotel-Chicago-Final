package com.hotel.reserva.service;

import com.hotel.reserva.model.Reserva;
import com.hotel.reserva.repository.ReservaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import java.util.List;

@Service
public class ReservaService {

    @Autowired
    private ReservaRepository repository;

    @Autowired
    private WebClient.Builder webClientBuilder;

    public List<Reserva> listarTodas() {
        return repository.findAll();
    }

    public Reserva guardar(Reserva reserva) {
        WebClient client = webClientBuilder.build();

        try {
            client.get()
                  .uri("http://localhost:8081/api/huespedes/" + reserva.getHuespedIdHuesped())
                  .retrieve().toBodilessEntity().block();
        } catch (Exception e) {
            throw new RuntimeException("Error: El Huésped con ID " + reserva.getHuespedIdHuesped() + " no existe o el servicio de Huéspedes está caído.");
        }

        try {
            client.get()
                  .uri("http://localhost:8082/api/habitaciones/" + reserva.getHabitacionIdHab())
                  .retrieve().toBodilessEntity().block();
        } catch (Exception e) {
            throw new RuntimeException("Error: La Habitación con ID " + reserva.getHabitacionIdHab() + " no existe o el servicio de Habitaciones está caído.");
        }

        try {
            client.get()
                  .uri("http://localhost:8084/api/temporadas/" + reserva.getTemporadaIdTemp())
                  .retrieve().toBodilessEntity().block();
        } catch (Exception e) {
            throw new RuntimeException("Error: La Temporada con ID " + reserva.getTemporadaIdTemp() + " no existe o el servicio de Temporadas está caído.");
        }

        return repository.save(reserva);
    }
}