package com.hotel.reserva.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;

@Entity
@Table(name = "reserva")
@Data
public class Reserva {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reserva")
    private Long idReserva;

    @Column(name = "fecha_ingreso")
    private LocalDate fechaIngreso;

    @Column(name = "fecha_salida")
    private LocalDate fechaSalida;

    @Column(name = "monto_reserva")
    private Double montoReserva;

    // Conexiones lógicas por ID hacia los otros microservicios
    @Column(name = "huesped_id_huesped")
    private Long huespedIdHuesped; // Puerto 8081

    @Column(name = "habitacion_id_hab")
    private Long habitacionIdHab; // Puerto 8082

    @Column(name = "temporada_id_temp")
    private Long temporadaIdTemp; // Puerto 8084
}